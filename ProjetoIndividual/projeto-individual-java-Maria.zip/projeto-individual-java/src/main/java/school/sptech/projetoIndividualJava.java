package school.sptech;
import java.util.Scanner;

public class projetoIndividualJava {
    static void main() {

        Scanner leitor = new Scanner(System.in);

        System.out.println("Quantos servidores você deseja monitorar?");
        Integer quantidade = leitor.nextInt();

        Integer quantidadeEmAlerta = 0;

        for (int i = 1; i <= quantidade; i++) {

            System.out.println("\nServidor " + i);

            System.out.println("CPU (%): ");
            Double cpu = leitor.nextDouble();

            System.out.println("Memória (%): ");
            Double memoria = leitor.nextDouble();

            System.out.println("Disco (%): ");
            Double disco = leitor.nextDouble();

            System.out.println("Rede (%): ");
            Double rede = leitor.nextDouble();

            if (cpu > 80 || memoria > 80 || disco > 80 || rede > 80) {
                System.out.println("Servidor apresenta risco");
                quantidadeEmAlerta++;
            } else {
                System.out.println("Servisor funcionando normalmente");
            }

            Boolean temProblema = false;

            System.out.println("\n Relatório do servidor " + i + ":\n");

            if (cpu > 80) {
                System.out.println("- CPU");
                temProblema = true;
            }

            if (memoria > 80) {
                System.out.println("- Memória");
                temProblema = true;
            }

            if (disco > 80) {
                System.out.println("- Disco");
                temProblema = true;
            }

            if (rede > 80) {
                System.out.println("- Rede");
                temProblema = true;
            }

            if (temProblema == false) {
                System.out.println("Nenhum problema encontrado.");

            }

            System.out.printf("\nServidores em alerta: %d \n", quantidadeEmAlerta);

        }
        leitor.close();
    }
}

