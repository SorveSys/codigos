package school.sptech;

public class Autenticador {

     Boolean autenticar(String usuarioDigitado, String senhaDigitada){
        if (usuarioDigitado.equals("pedro") && senhaDigitada.equals("123")){
            System.out.println("Credenciais verificadas!");
            return true;
        } else {
            System.out.println("Usuário ou senha incorretos.");
            return false;
        }
     }
    Double calcularPrejuizo(Integer horasParadas, Integer quantidadePracas) {

        return  horasParadas * quantidadePracas * 10000.0;
    }

    Double calcularEconomia(Double prejuizoTotal) {

        return prejuizoTotal*0.85;
    }
}
