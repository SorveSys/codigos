package school.sptech;
import java.util.Scanner;

public class main {
    static void main(String[] args){
        Scanner usuario = new Scanner(System.in);
        Scanner senha = new Scanner(System.in);
        boolean logado = false;
        Autenticador auth = new Autenticador();

        while (!logado) {
            System.out.println("digite o seu nome ");
            String nome = usuario.nextLine();

            System.out.println("Digite a sua senha ");
            String validar = senha.nextLine();

            logado = auth.autenticar(nome, validar);
        }

            System.out.println("Olá! Login feito com sucesso.");

        System.out.println("Digite a quantidade de praças de pedágio:");
        Integer pracas = usuario.nextInt();

        System.out.println("Digite o total de horas de servidores parados/fora do ar:");
        Integer horas = usuario.nextInt();

        Double prejuizoTotal = auth.calcularPrejuizo(horas, pracas);

        Double economia = auth.calcularEconomia(prejuizoTotal);


        System.out.println("\n Resultado");
        System.out.println("Prejuízo estimado sem monitoramento: R$ " + prejuizoTotal);
        System.out.println("Economia estimada de 85%: R$ " + economia);
    }
}
