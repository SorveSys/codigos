package sptech.school;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class LeituraHardware {

    Maquina maquina;
    String recurso;
    Integer valorUso;
    LocalDateTime dataHora;

    public String classificarUso(){

        String mensagemUso = "";

        if(valorUso >= 85){
            mensagemUso = "Crítico";
        }
        else if(valorUso >= 60){
            mensagemUso = "Alto";
        }
        else{
            mensagemUso = "Normal";
        }

        return mensagemUso;
    }

    void exibirLeitura(){

        DateTimeFormatter formatoData = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");
        String dataFormatada = dataHora.format(formatoData);

        System.out.printf("""
                [%s] Máquina: %s
                Leitura de uso de: %s
                Uso: %d%% | Status: %s
                ========================================
                """,dataFormatada,maquina.getNome(),recurso,valorUso,classificarUso());
    }
}
