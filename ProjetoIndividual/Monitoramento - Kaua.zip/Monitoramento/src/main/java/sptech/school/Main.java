package sptech.school;

import java.lang.reflect.Array;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.concurrent.ThreadLocalRandom;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {

    public static void main(String[] args) {

        Maquina m1 = new Maquina();
        m1.id = 1;
        m1.nome = "Kauã";
        m1.localizacao = "Norte";

        Maquina m2 = new Maquina();
        m2.id = 2;
        m2.nome = "Oliveira";
        m2.localizacao = "Sul";

        Maquina m3 = new Maquina();
        m3.id = 3;
        m3.nome = "Pedroso";
        m3.localizacao = "Oeste";

        Scanner leitorNumero = new Scanner(System.in);
        Scanner leitorTexto = new Scanner(System.in);

        ArrayList<LeituraHardware> historico = new ArrayList<>();


        Boolean sistemaOperando = true;
        System.out.println("----- Sistema de Monitoramento -----");

        while (sistemaOperando == true){
            System.out.printf("""
                    Escolha a Máquina a ser Monitorada:
                    1- Máquina 1
                    2- Máquina 2
                    3- Máquina 3
                    0- Sair
                    """);

            Integer escolhaMaquina = leitorNumero.nextInt();
            if(escolhaMaquina == 0){
                System.out.println("==================== Encerrando Sistema ====================");
                sistemaOperando = false;
                        break;
            }

            System.out.printf("""
                    O que deseja Monitorar:
                    1- CPU
                    2- RAM
                    3- Disco
                    """);

            Integer escolhaRecurso = leitorNumero.nextInt();
            String recursoEscolhido = "";

            if(escolhaRecurso == 1){
                recursoEscolhido = "CPU";
            }
            else if(escolhaRecurso == 2){
                recursoEscolhido = "RAM";
            }
            else if(escolhaRecurso == 3){
                recursoEscolhido = "Disco";
            }
            else{
                System.out.println("==================== Recurso Não Encontrado, Tente Novamente ====================");
                continue;
            }

            Maquina maquinaEscolhida = new Maquina();
            if(escolhaMaquina == 1){
                maquinaEscolhida = m1;
            }
            else if(escolhaMaquina == 2){
                maquinaEscolhida = m2;
            }
            else if(escolhaMaquina == 3){
                maquinaEscolhida = m3;
            }
            else{
                System.out.println("==================== Máquina Não Encontrada, Tente Novamente ==================== ");
                continue;
            }

            LeituraHardware leitura = new LeituraHardware();
            leitura.maquina = maquinaEscolhida;
            leitura.recurso = recursoEscolhido;
            leitura.valorUso = ThreadLocalRandom.current().nextInt(0,101);
            leitura.dataHora = LocalDateTime.now();

            historico.add(leitura);

            System.out.println("========================================");
            leitura.exibirLeitura();
            System.out.println("Total de leituras no Histórico: " + historico.size() + "\n========================================");
        }
    }
    }
