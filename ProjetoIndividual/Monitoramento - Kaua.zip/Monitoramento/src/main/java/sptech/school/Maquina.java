package sptech.school;

public class Maquina {

    Integer id;
    String nome;
    String localizacao;

    public String getNome(){
        return nome;
    }
}
