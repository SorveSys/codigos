package sptech.example;

public class Empresa {
    Integer id;
    String razaoSocial;
    String nomeFantasia;
    String cnpj;
    String email;

    public String getNome() {
        return nomeFantasia;
    }
}