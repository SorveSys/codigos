package sptech.example;

import java.lang.reflect.Array;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.concurrent.ThreadLocalRandom;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {

    public static void main(String[] args) {

        Maquina maquinaCadastrada = null;

        Empresa empresa1 = new Empresa();
        empresa1.id = 1;
        empresa1.razaoSocial = "Rodovia Segura Monitoramento LTDA";
        empresa1.nomeFantasia = "Rodovia Segura";
        empresa1.cnpj = "12.345.678/0001-90";
        empresa1.email = "contato@rodoviasegura.com";

        Empresa empresa2 = new Empresa();
        empresa2.id = 2;
        empresa2.razaoSocial = "EcoRodovias Infraestrutura e Logística S/A";
        empresa2.nomeFantasia = "EcoRodovias";
        empresa2.cnpj = "04.149.454/0001-80";
        empresa2.email = "contato@ecorodovias.com";

        Empresa empresa3 = new Empresa();
        empresa3.id = 3;
        empresa3.razaoSocial = "Sem Parar Instituição de Pagamento Ltda";
        empresa3.nomeFantasia = "Sem Parar";
        empresa3.cnpj = "04.088.208/0001-65";
        empresa3.email = "contato@semparar.com";

        Scanner leitorNumero = new Scanner(System.in);
        Scanner leitorTexto = new Scanner(System.in);

        ArrayList<LeituraHardware> historico = new ArrayList<>();
        ArrayList<Maquina> listaMaquinas = new ArrayList<>();

        Integer contadorIdMaquina = 1;

        Boolean sistemaOperando = true;
        System.out.println("----- Sistema de Monitoramento -----");

        while (sistemaOperando == true) {
            System.out.printf("""
                    Escolha a Empresa para cadastrar a Máquina:
                    1- Rodovia Segura
                    2- EcoRodovias
                    3- Sem Parar
                    0- Sair
                    """);

            Integer escolhaEmpresa = leitorNumero.nextInt();

            if (escolhaEmpresa == 0) {
                System.out.println("==================== Encerrando Sistema ====================");
                sistemaOperando = false;

                System.out.println("\n--- RELATÓRIO DE MÁQUINAS CADASTRADAS ---");
                if (listaMaquinas.isEmpty()) {
                    System.out.println("Nenhuma máquina foi cadastrada.");
                } else {
                    for (int i = 0; i < listaMaquinas.size(); i++) {
                        Maquina m = listaMaquinas.get(i);
                        System.out.printf("ID: %d | Hostname: %s | MAC: %s | Empresa: %s\n",
                                m.id, m.getNome(), m.macAddress, m.empresa.getNome());
                    }
                }

                System.out.println("=============================================================");
                break;
            } else {
                Empresa empresaEscolhida = new Empresa();
                if (escolhaEmpresa == 1) {
                    empresaEscolhida = empresa1;
                } else if (escolhaEmpresa == 2) {
                    empresaEscolhida = empresa2;
                } else {
                    empresaEscolhida = empresa3;
                }

                System.out.println("Hostname da Máquina: ");
                String hostMaq = leitorTexto.nextLine();
                System.out.println("Mac Address: ");
                String macMaq = leitorTexto.nextLine();

                maquinaCadastrada = new Maquina(contadorIdMaquina, hostMaq, macMaq, empresaEscolhida);

                listaMaquinas.add(maquinaCadastrada);
                contadorIdMaquina++;

                System.out.println("Máquina cadastrada com sucesso!");
            }

            System.out.printf("""
                    O que deseja Monitorar:
                    1 - CPU
                    2 - RAM
                    3 - Disco
                    4 - Rede
                    """);

            Integer escolhaRecurso = leitorNumero.nextInt();
            String recursoEscolhido = "";

            if (escolhaRecurso == 1) {
                recursoEscolhido = "CPU";
            } else if (escolhaRecurso == 2) {
                recursoEscolhido = "RAM";
            } else if (escolhaRecurso == 3) {
                recursoEscolhido = "Disco";
            } else if (escolhaRecurso == 4) {
                recursoEscolhido = "Rede";
            } else {
                System.out.println("Recurso não encontrado! Tente Novamente.");
                continue;
            }

            LeituraHardware leitura = new LeituraHardware();
            leitura.maquina = maquinaCadastrada;
            leitura.recurso = recursoEscolhido;
            leitura.valorUso = ThreadLocalRandom.current().nextInt(0, 101);
            leitura.dataHora = LocalDateTime.now();

            historico.add(leitura);

            System.out.println("========================================");
            leitura.exibirLeitura();
            System.out.println("Total de leituras no Histórico: " + historico.size() + "\n========================================");
        }
    }
}