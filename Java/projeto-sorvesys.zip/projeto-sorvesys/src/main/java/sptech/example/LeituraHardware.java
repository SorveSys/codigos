package sptech.example;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class LeituraHardware {

    Maquina maquina;
    String recurso;
    Integer valorUso;
    LocalDateTime dataHora;

    public String classificarUso() {

        String mensagemUso = "";

        Integer limiteCritico = 85;
        Integer limiteAlto = 60;

        if (recurso != null) {
            if (recurso.equalsIgnoreCase("CPU")) {
                limiteCritico = 85;
                limiteAlto = 65;
            } else if (recurso.equalsIgnoreCase("RAM")) {
                limiteCritico = 90;
                limiteAlto = 75;
            } else if (recurso.equalsIgnoreCase("Disco")) {
                limiteCritico = 95;
                limiteAlto = 80;
            } else if (recurso.equalsIgnoreCase("Rede")) {
                limiteCritico = 80;
                limiteAlto = 50;
            }
        }

        if (valorUso >= limiteCritico) {
            mensagemUso = "Crítico";
        } else if (valorUso >= limiteAlto) {
            mensagemUso = "Alto";
        } else {
            mensagemUso = "Normal";
        }

        return mensagemUso;
    }

    void exibirLeitura() {
        DateTimeFormatter formatoData = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");
        String dataFormatada = dataHora.format(formatoData);

        System.out.printf("""
                [%s] Máquina: %s
                Leitura de uso de: %s
                Uso: %d%% | Status: %s
                ========================================
                """, dataFormatada, maquina.getNome(), recurso, valorUso, classificarUso());
    }
}