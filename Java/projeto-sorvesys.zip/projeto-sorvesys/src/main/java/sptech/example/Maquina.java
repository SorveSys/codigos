package sptech.example;

public class Maquina {
    Integer id;
    String hostname;
    String macAddress;
    Empresa empresa;

    Maquina(Integer pId, String pHostname, String pMacAddress, Empresa empresaEscolhida) {
        id = pId;
        hostname = pHostname;
        macAddress = pMacAddress;
        empresa = empresaEscolhida;
    }

    public String getNome() {
        return hostname;
    }
}